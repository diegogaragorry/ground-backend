import { Response } from "express";
import { prisma } from "../lib/prisma";
import { toUsd } from "../utils/fx";
import type { AuthRequest } from "../middlewares/requireAuth";

function parseYearMonth(query: any) {
  const year = Number(query.year);
  const month = Number(query.month);

  if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) {
    return null;
  }
  return { year, month };
}

export const createExpense = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const { description, amount, date, categoryId, currencyId, usdUyuRate } = req.body ?? {};

  if (!description || typeof description !== "string") {
    return res.status(400).json({ error: "description is required" });
  }
  if (typeof amount !== "number" || !(amount > 0)) {
    return res.status(400).json({ error: "amount must be a number > 0" });
  }
  if (!date || typeof date !== "string" || Number.isNaN(Date.parse(date))) {
    return res.status(400).json({ error: "date must be an ISO date string" });
  }
  if (!categoryId || typeof categoryId !== "string") {
    return res.status(400).json({ error: "categoryId is required" });
  }
  if (!currencyId || typeof currencyId !== "string") {
    return res.status(400).json({ error: "currencyId is required (e.g., UYU, USD)" });
  }

  // Seguridad: validar que la categoría sea del usuario
  const category = await prisma.category.findFirst({
    where: { id: categoryId, userId },
  });
  if (!category) {
    return res.status(403).json({ error: "Invalid categoryId for this user" });
  }

  // Validar moneda existe
  const currency = await prisma.currency.findUnique({ where: { id: currencyId } });
  if (!currency) {
    return res.status(400).json({ error: "Invalid currencyId" });
  }

  // FX: 1 USD = X UYU (si currencyId es UYU)
  let fx: { amountUsd: number; usdUyuRate: number | null };
  try {
    fx = toUsd({ amount, currencyId, usdUyuRate });
  } catch (e: any) {
    return res.status(400).json({ error: e?.message ?? "Invalid FX rate" });
  }

  const expense = await prisma.expense.create({
    data: {
      userId,
      categoryId,
      currencyId,
      description,
      amount,
      amountUsd: fx.amountUsd,
      usdUyuRate: fx.usdUyuRate,
      date: new Date(date),
    },
    include: {
      category: true,
      currency: true,
    },
  });

  return res.status(201).json(expense);
};

export const listExpensesByMonth = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const ym = parseYearMonth(req.query);

  if (!ym) {
    return res
      .status(400)
      .json({ error: "Provide year and month query params (e.g., ?year=2026&month=1)" });
  }

  const start = new Date(Date.UTC(ym.year, ym.month - 1, 1, 0, 0, 0));
  const end = new Date(Date.UTC(ym.year, ym.month, 1, 0, 0, 0));

  const expenses = await prisma.expense.findMany({
    where: {
      userId,
      date: { gte: start, lt: end },
    },
    orderBy: { date: "desc" },
    include: {
      category: true,
      currency: true,
    },
  });

  res.json(expenses);
};

export const expensesSummary = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const ym = parseYearMonth(req.query);

  if (!ym) {
    return res
      .status(400)
      .json({ error: "Provide year and month query params (e.g., ?year=2026&month=1)" });
  }

  const start = new Date(Date.UTC(ym.year, ym.month - 1, 1, 0, 0, 0));
  const end = new Date(Date.UTC(ym.year, ym.month, 1, 0, 0, 0));

  // ✅ Summary en USD (core de la app)
  const grouped = await prisma.expense.groupBy({
    by: ["categoryId"],
    where: {
      userId,
      date: { gte: start, lt: end },
    },
    _sum: { amountUsd: true },
  });

  // Enriquecemos con nombres
  const categoryIds = [...new Set(grouped.map((g) => g.categoryId))];
  const categories = await prisma.category.findMany({
    where: { id: { in: categoryIds }, userId },
  });
  const categoryMap = new Map(categories.map((c) => [c.id, c.name]));

  const result = grouped.map((g) => ({
    categoryId: g.categoryId,
    categoryName: categoryMap.get(g.categoryId) ?? "(unknown)",
    currencyId: "USD",
    total: g._sum.amountUsd ?? 0,
  }));

  res.json({
    year: ym.year,
    month: ym.month,
    totalsByCategoryAndCurrency: result,
  });
};

export const updateExpense = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const id = req.params.id;

  const existing = await prisma.expense.findFirst({ where: { id, userId } });
  if (!existing) return res.status(404).json({ error: "Expense not found" });

  const { description, amount, date, categoryId, currencyId, usdUyuRate } = req.body ?? {};

  // Permitimos update parcial
  const data: any = indicatingData();

  function indicatingData() {
    return {};
  }

  if (description !== undefined) {
    if (typeof description !== "string" || !description) {
      return res.status(400).json({ error: "description must be a non-empty string" });
    }
    data.description = description;
  }

  if (amount !== undefined) {
    if (typeof amount !== "number" || !(amount > 0)) {
      return res.status(400).json({ error: "amount must be a number > 0" });
    }
    data.amount = amount;
  }

  if (date !== undefined) {
    if (typeof date !== "string" || Number.isNaN(Date.parse(date))) {
      return res.status(400).json({ error: "date must be an ISO date string" });
    }
    data.date = new Date(date);
  }

  if (categoryId !== undefined) {
    if (typeof categoryId !== "string") {
      return res.status(400).json({ error: "categoryId must be a string" });
    }

    const category = await prisma.category.findFirst({ where: { id: categoryId, userId } });
    if (!category) return res.status(403).json({ error: "Invalid categoryId for this user" });

    data.categoryId = categoryId;
  }

  if (currencyId !== undefined) {
    if (typeof currencyId !== "string") {
      return res.status(400).json({ error: "currencyId must be a string" });
    }

    const currency = await prisma.currency.findUnique({ where: { id: currencyId } });
    if (!currency) return res.status(400).json({ error: "Invalid currencyId" });

    data.currencyId = currencyId;
  }

  if (usdUyuRate !== undefined) {
    if (typeof usdUyuRate !== "number" || !(usdUyuRate > 0)) {
      return res
        .status(400)
        .json({ error: "usdUyuRate must be a number > 0 (1 USD = X UYU)" });
    }
    data.usdUyuRate = usdUyuRate;
  }

  // Recalcular amountUsd si cambia amount o currency o usdUyuRate
  if (amount !== undefined || currencyId !== undefined || usdUyuRate !== undefined) {
    const finalAmount = amount !== undefined ? amount : (existing as any).amount;
    const finalCurrencyId =
      currencyId !== undefined ? currencyId : (existing as any).currencyId;
    const finalUsdUyuRate =
      usdUyuRate !== undefined
        ? usdUyuRate
        : ((existing as any).usdUyuRate ?? undefined);

    try {
      const fx = toUsd({
        amount: finalAmount,
        currencyId: finalCurrencyId,
        usdUyuRate: finalUsdUyuRate,
      });
      data.amountUsd = fx.amountUsd;
      data.usdUyuRate = fx.usdUyuRate;
    } catch (e: any) {
      return res.status(400).json({ error: e?.message ?? "Invalid FX rate" });
    }
  }

  const updated = await prisma.expense.update({
    where: { id },
    data,
    include: { category: true, currency: true },
  });

  res.json(updated);
};

export const deleteExpense = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const id = req.params.id;

  const existing = await prisma.expense.findFirst({ where: { id, userId } });
  if (!existing) return res.status(404).json({ error: "Expense not found" });

  await prisma.expense.delete({ where: { id } });
  res.status(204).send();
};
