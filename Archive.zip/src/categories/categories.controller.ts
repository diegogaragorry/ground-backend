import { Response } from "express";
import { prisma } from "../lib/prisma";
import type { AuthRequest } from "../middlewares/requireAuth";

export const listCategories = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const categories = await prisma.category.findMany({
    where: { userId },
    orderBy: { name: "asc" },
  });
  res.json(categories);
};

export const createCategory = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const { name } = req.body ?? {};

  if (!name || typeof name !== "string") {
    return res.status(400).json({ error: "name is required" });
  }

  const category = await prisma.category.create({
    data: { name, userId },
  });

  res.status(201).json(category);
};

export const updateCategory = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const id = req.params.id;
  const { name } = req.body ?? {};

  if (!name || typeof name !== "string") {
    return res.status(400).json({ error: "name is required" });
  }

  const category = await prisma.category.findFirst({ where: { id, userId } });
  if (!category) return res.status(404).json({ error: "Category not found" });

  const updated = await prisma.category.update({
    where: { id },
    data: { name },
  });

  res.json(updated);
};

export const deleteCategory = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const id = req.params.id;

  const category = await prisma.category.findFirst({ where: { id, userId } });
  if (!category) return res.status(404).json({ error: "Category not found" });

  // Si hay gastos asociados, Prisma va a fallar por FK.
  // Para UX linda: devolvemos error claro.
  try {
    await prisma.category.delete({ where: { id } });
    return res.status(204).send();
  } catch {
    return res.status(409).json({ error: "Cannot delete category with expenses linked" });
  }
};
