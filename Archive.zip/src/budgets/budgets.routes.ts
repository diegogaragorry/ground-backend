import { Router } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import { upsertBudget, listBudgets, budgetReport } from "./budgets.controller";

const router = Router();

router.post("/", requireAuth, upsertBudget);
router.get("/", requireAuth, listBudgets);
router.get("/report", requireAuth, budgetReport);

export default router;
