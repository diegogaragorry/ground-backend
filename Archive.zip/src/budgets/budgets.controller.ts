import { Response } from "express";
import { prisma } from "../lib/prisma";
import type { AuthRequest } from "../middlewares/requireAuth";

function parseYearMonth(query: any) {
  const year = Number(query.year);
  const month = Number(query.month);
  if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) return null;
  return { year, month };
}

export const upsertBudget = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const { year, month, categoryId, currencyId, amount } = req.body ?? {};

  if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) {
    return res.status(400).json({ error: "year and month are required (month 1-12)" });
  }
  if (!categoryId || typeof categoryId !== "string") return res.status(400).json({ error: "categoryId is required" });
  if (!currencyId || typeof currencyId !== "string") return res.status(400).json({ error: "currencyId is required" });
  if (typeof amount !== "number" || amount < 0) return res.status(400).json({ error: "amount must be a number >= 0" });

  // validar category del usuario
  const category = await prisma.category.findFirst({ where: { id: categoryId, userId } });
  if (!category) return res.status(403).json({ error: "Invalid categoryId for this user" });

  // validar moneda
  const currency = await prisma.currency.findUnique({ where: { id: currencyId } });
  if (!currency) return res.status(400).json({ error: "Invalid currencyId" });

  // Upsert: un presupuesto por (userId, year, month, categoryId, currencyId)
  // Para esto conviene tener un índice único. Como no lo tenemos aún, hacemos "find+update/create".
  const existing = await prisma.budget.findFirst({
    where: { userId, year, month, categoryId, currencyId },
  });

  const budget = await prisma.budget.upsert({
  where: {
    userId_year_month_categoryId_currencyId: {
      userId,
      year,
      month,
      categoryId,
      currencyId,
    },
  },
  update: { amount },
  create: { userId, year, month, categoryId, currencyId, amount },
});

res.status(200).json(budget);

};

export const listBudgets = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const ym = parseYearMonth(req.query);
  if (!ym) return res.status(400).json({ error: "Provide year and month query params (e.g., ?year=2026&month=1)" });

  const budgets = await prisma.budget.findMany({
    where: { userId, year: ym.year, month: ym.month },
    include: { category: true, currency: true },
    orderBy: [{ currencyId: "asc" }, { categoryId: "asc" }],
  });

  res.json(budgets);
};

export const budgetReport = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const ym = parseYearMonth(req.query);
  if (!ym) return res.status(400).json({ error: "Provide year and month query params (e.g., ?year=2026&month=1)" });

  const start = new Date(Date.UTC(ym.year, ym.month - 1, 1, 0, 0, 0));
  const end = new Date(Date.UTC(ym.year, ym.month, 1, 0, 0, 0));

  const budgets = await prisma.budget.findMany({
    where: { userId, year: ym.year, month: ym.month },
    include: { category: true, currency: true },
  });

  const actuals = await prisma.expense.groupBy({
    by: ["categoryId", "currencyId"],
    where: { userId, date: { gte: start, lt: end } },
    _sum: { amount: true },
  });

  const actualMap = new Map<string, number>();
  for (const a of actuals) {
    actualMap.set(`${a.categoryId}:${a.currencyId}`, a._sum.amount ?? 0);
  }

  const rows = budgets.map((b) => {
    const actual = actualMap.get(`${b.categoryId}:${b.currencyId}`) ?? 0;
    const budget = b.amount;
    const diff = budget - actual;
    const pct = budget === 0 ? null : actual / budget;

    return {
      categoryId: b.categoryId,
      categoryName: b.category.name,
      currencyId: b.currencyId,
      budget,
      actual,
      diff,
      pct,
    };
  });

  res.json({ year: ym.year, month: ym.month, rows });
};
