import { Router } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import {
  createInvestment,
  listInvestments,
  addMovement,
  investmentPerformance,
} from "./investments.controller";

const router = Router();

router.post("/", requireAuth, createInvestment);
router.get("/", requireAuth, listInvestments);
router.post("/:id/movements", requireAuth, addMovement);
router.get("/:id/performance", requireAuth, investmentPerformance);

export default router;
