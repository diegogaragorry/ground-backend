import { Response } from "express";
import { prisma } from "../lib/prisma";
import type { AuthRequest } from "../middlewares/requireAuth";

const MOVEMENT_TYPES = new Set(["deposit", "withdrawal", "yield"] as const);

export const createInvestment = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const { name, type } = req.body ?? {};

  if (!name || typeof name !== "string") return res.status(400).json({ error: "name is required" });
  if (!type || typeof type !== "string") return res.status(400).json({ error: "type is required" });

  const inv = await prisma.investment.create({
    data: { name, type, userId },
  });

  res.status(201).json(inv);
};

export const listInvestments = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const investments = await prisma.investment.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
  res.json(investments);
};

export const addMovement = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const investmentId = req.params.id;

  const { date, amount, type, currencyId } = req.body ?? {};

  if (!date || typeof date !== "string" || Number.isNaN(Date.parse(date))) {
    return res.status(400).json({ error: "date must be an ISO date string" });
  }
  if (typeof amount !== "number" || !(amount > 0)) {
    return res.status(400).json({ error: "amount must be a number > 0" });
  }
  if (!type || typeof type !== "string" || !MOVEMENT_TYPES.has(type as any)) {
    return res.status(400).json({ error: "type must be one of: deposit, withdrawal, yield" });
  }
  if (!currencyId || typeof currencyId !== "string") {
    return res.status(400).json({ error: "currencyId is required (e.g., UYU, USD)" });
  }

  // Seguridad: inversión debe ser del usuario
  const inv = await prisma.investment.findFirst({
    where: { id: investmentId, userId },
  });
  if (!inv) return res.status(404).json({ error: "Investment not found" });

  // Validar moneda existe
  const currency = await prisma.currency.findUnique({ where: { id: currencyId } });
  if (!currency) return res.status(400).json({ error: "Invalid currencyId" });

  const movement = await prisma.investmentMovement.create({
    data: {
      investmentId,
      date: new Date(date),
      amount,
      type,
      currencyId,
    },
    include: { currency: true },
  });

  res.status(201).json(movement);
};

export const investmentPerformance = async (req: AuthRequest, res: Response) => {
  const userId = req.userId!;
  const investmentId = req.params.id;

  const inv = await prisma.investment.findFirst({
    where: { id: investmentId, userId },
  });
  if (!inv) return res.status(404).json({ error: "Investment not found" });

  const movements = await prisma.investmentMovement.findMany({
    where: { investmentId },
    orderBy: { date: "asc" },
  });

  // MVP: calcular por moneda (sin FX). Sumamos por currencyId
  type Totals = { deposits: number; withdrawals: number; yield: number; balance: number; netContrib: number; roi: number | null };
  const totalsByCurrency: Record<string, Totals> = {};

  for (const m of movements) {
    const cur = m.currencyId;
    totalsByCurrency[cur] ??= { deposits: 0, withdrawals: 0, yield: 0, balance: 0, netContrib: 0, roi: null };

    if (m.type === "deposit") totalsByCurrency[cur].deposits += m.amount;
    if (m.type === "withdrawal") totalsByCurrency[cur].withdrawals += m.amount;
    if (m.type === "yield") totalsByCurrency[cur].yield += m.amount;
  }

  for (const cur of Object.keys(totalsByCurrency)) {
    const t = totalsByCurrency[cur];
    t.netContrib = t.deposits - t.withdrawals;
    t.balance = t.netContrib + t.yield;
    t.roi = t.netContrib === 0 ? null : t.yield / t.netContrib; // ROI simple sobre aporte neto
  }

  res.json({
    investment: inv,
    totalsByCurrency,
    movementsCount: movements.length,
  });
};
