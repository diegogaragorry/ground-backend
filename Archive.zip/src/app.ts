import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";

import authRoutes from "./auth/auth.routes";
import { requireAuth } from "./middlewares/requireAuth";
import type { AuthRequest } from "./middlewares/requireAuth";
import categoryRoutes from "./categories/categories.routes";
import expenseRoutes from "./expenses/expenses.routes";
import budgetRoutes from "./budgets/budgets.routes";
import investmentRoutes from "./investments/investments.routes";

const app = express();

// ✅ CORS primero (antes de rutas)
app.use(cors({ origin: ["http://localhost:5173", "http://localhost:5174"] }));

// ✅ JSON después
app.use(express.json());

// ✅ rutas
app.use("/auth", authRoutes);
app.use("/categories", categoryRoutes);
app.use("/expenses", expenseRoutes);
app.use("/budgets", budgetRoutes);
app.use("/investments", investmentRoutes);

app.get("/health", (_, res) => {
  res.json({ status: "ok" });
});

app.get("/me", requireAuth, (req: AuthRequest, res) => {
  res.json({ userId: req.userId });
});

export default app;
