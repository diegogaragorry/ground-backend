import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  await prisma.currency.upsert({
    where: { id: "UYU" },
    update: {},
    create: { id: "UYU", name: "Uruguayan Peso" },
  });

  await prisma.currency.upsert({
    where: { id: "USD" },
    update: {},
    create: { id: "USD", name: "US Dollar" },
  });

  console.log("✅ Seed completed: currencies (UYU, USD)");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
